Game Studio - Modular Puzzle Game Collection
============================================

To run the game:
1. Make sure all DLL files are in the same directory as GameStudio.exe
2. Double-click GameStudio.exe

System Requirements:
- Windows 7 or later
- OpenGL compatible graphics card

Included Games:
- Tic-Tac-Toe
- 2048 Puzzle
- Sudoku

For issues or questions, please contact the developer.

Files Included:
assets
GameStudio.exe
libgcc_s_seh-1.dll
libstdc++-6.dll
libwinpthread-1.dll
openal32.dll
README.txt
scores.txt
sfml-audio-2.dll
sfml-graphics-2.dll
sfml-network-2.dll
sfml-system-2.dll
sfml-window-2.dll
